<?php
require('./config.php');
use Web3\Contract;


if ($_SERVER['REQUEST_METHOD'] === 'POST') {


	$eth = $web3->eth;
	$walletAddress = $_POST['address'];
	$etherTokenBalance = '';
	/**
	 * getBalance
	 * get Ether Balance
	 *
	 * @var string
	 */
	 $eth->getBalance($walletAddress, function ($err, $balance) use(&$etherTokenBalance) {
				/* if ($err !== null) {
					echo 'Error: ' . $err->getMessage();
					return;
				} */
			  $etherTokenBalance = $balance->toString();
			});


	/**
	 * testAbi
	 * GameToken abi from https://github.com/sc0Vu/GameToken
	 *
	 * @var string
	 */
	$testAbi = '[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"initialSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_value","type":"uint256"}],"name":"burn","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_subtractedValue","type":"uint256"}],"name":"decreaseApproval","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_addedValue","type":"uint256"}],"name":"increaseApproval","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"remaining","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"name":"previousOwner","type":"address"},{"indexed":true,"name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"burner","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Burn","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"owner","type":"address"},{"indexed":true,"name":"spender","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"}]';


	$contractAddress = '0xB39E463bfD92d313322C700deC45fe298C0f4709'; 
	$functionName = "balanceOf";
	$contract = new Contract($web3->provider, $testAbi);
	$hedTokenBalance = '';

	$functionData = $contract->at($contractAddress)->call($functionName, $walletAddress,function($err, $result)use(&$hedTokenBalance){
		$hedTokenBalance = $result['balance']->toString();
	});
	if($hedTokenBalance!='' && $hedTokenBalance!=0) {
		$hedTokenBalance = $hedTokenBalance/1000000000000000000;
	}
	if($etherTokenBalance!='' && $etherTokenBalance!=0) {
		$etherTokenBalance = $etherTokenBalance/1000000000000000000;
	}
	
	
	$balanceArr = ['eth'=>$etherTokenBalance,'intaro'=>$hedTokenBalance];
	$returnArr = [];
	$returnArr['success'] = true;
	$returnArr['message'] = "get balance";
	$returnArr['data'] = $balanceArr;


}
else {
	$returnArr = [];
	$returnArr['success'] = false;
	$returnArr['message'] = "Invalid Request";
	$returnArr['data'] = [];
	
}
echo json_encode($returnArr);